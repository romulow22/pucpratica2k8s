// import { rest } from 'msw';

// export const handlers = [
//   rest.get('/api/game/:id', (req, res, ctx) => {
//     const { id } = req.params;
//     return res(
//       ctx.json({ id, word: 'apple' })
//     );
//   }),
//   // Add more request handlers as needed
// ];